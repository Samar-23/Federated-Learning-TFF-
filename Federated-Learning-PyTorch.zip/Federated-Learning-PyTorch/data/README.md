## Datasets

- Download the required datasets in the respective directories
- Add your custom dataset in a separate directory.
